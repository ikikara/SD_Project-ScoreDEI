package com.example.formdata;

public class FormTeamVsTeam {
    private String idA, idB;
    public FormTeamVsTeam(){
        
    }

    public String getIdA() {
        return this.idA;
    }

    public void setIdA(String idA) {
        this.idA = idA;
    }

    public String getIdB() {
        return this.idB;
    }

    public void setIdB(String idB) {
        this.idB = idB;
    }

}
